package com.wcs.firstsite.customrest.beans;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ProductBean {
	String productName;
	String productId;
	String productSKU;
	String productLongDescription;
	String productShortDescription;
	Double productPrice;
	Long productImage;
	MediaBean media;
	
	public MediaBean getMedia() {
		return media;
	}
	public void setMedia(MediaBean media) {
		this.media = media;
	}
	public Long getProductImage() {
		return productImage;
	}
	public void setProductImage(Long productImage) {
		this.productImage = productImage;
	}
	public String getProductShortDescription() {
		return productShortDescription;
	}
	public void setProductShortDescription(String productShortDescription) {
		this.productShortDescription = productShortDescription;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductSKU() {
		return productSKU;
	}
	public void setProductSKU(String productSKU) {
		this.productSKU = productSKU;
	}
	public String getProductLongDescription() {
		return productLongDescription;
	}
	public void setProductLongDescription(String productLongDescription) {
		this.productLongDescription = productLongDescription;
	}
	public Double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(Double productPrice) {
		this.productPrice = productPrice;
	}
}
