package com.wcs.firstsite.customrest.beans;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class RecommendationBean {

    public List<ProductBean> assets;
    String description;

    public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<ProductBean> getAssets() {
        if (assets == null) {
            assets = new ArrayList<ProductBean>();
        }
        return this.assets;
    }
}
