package com.wcs.firstsite.customrest.beans;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class AssetBean {
	ProductBean product;
	RecommendationBean recom;
	MediaBean media;
	
	public MediaBean getMedia() {
		return media;
	}
	public void setMedia(MediaBean media) {
		this.media = media;
	}
	public ProductBean getProduct() {
		return product;
	}
	public void setProduct(ProductBean product) {
		this.product = product;
	}
	public RecommendationBean getRecom() {
		return recom;
	}
	public void setRecom(RecommendationBean recom) {
		this.recom = recom;
	}
	
}
