package com.wcs.firstsite.customrest.config;

import com.sun.jersey.api.json.JSONJAXBContext;
import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.Provider;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

@Provider
public final class JAXBContextResolver
  implements ContextResolver<JAXBContext>
{
  private final JAXBContext context = new JSONJAXBContext(new Class[0]);

  public JAXBContextResolver()
    throws JAXBException
  {
  }

  public JAXBContext getContext(Class<?> paramClass)
  {
    return this.context;
  }
}