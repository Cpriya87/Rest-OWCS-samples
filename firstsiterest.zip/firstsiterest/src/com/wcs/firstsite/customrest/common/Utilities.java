package com.wcs.firstsite.customrest.common;

import java.io.IOException;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fatwire.assetapi.data.AssetDataManager;
import com.fatwire.system.Session;
import com.fatwire.system.SessionFactory;
import com.fatwire.wem.sso.cas.CASProvider;
import com.fatwire.wem.sso.cas.conf.CASConfig;
import com.openmarket.xcelerate.util.XcelProperties;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.WebResource.Builder;

import COM.FutureTense.CS.Factory;
import COM.FutureTense.Interfaces.ICS;
import COM.FutureTense.Interfaces.IPS;
import COM.FutureTense.Servlet.IPSRegistry;

public class Utilities {
	
	private static final Log LOG = LogFactory.getLog(Utilities.class);
	private static Properties property = new Properties();
	private static final String VALIDATION_PROPERTIES = "validation.properties";
	
	private static void init() throws IOException {
        LOG.debug("action=init, step=start");
        try {
            ClassLoader loader = Thread.currentThread().getContextClassLoader();
            property.load(loader.getResourceAsStream(VALIDATION_PROPERTIES));
        } catch (Exception e) {
            LOG.error("Exception occured in init method of utilities class", e);
        }
        LOG.debug("Utilities class init method completed");
    }
	
	static{
	    try
	    {
	      init();
	    }
	    catch (IOException localIOException)
	    {
	      LOG.error("Failed to load the validation properties file in static init method ", localIOException);
	    }
	}
	
	public static String getFileProperty(String propertyName) {
    	return property.getProperty(propertyName);
    }
	
	public static ICS getICSInstance(){
    	ICS ics = null;
        IPS ips = IPSRegistry.getInstance().get();
        ics = (ips != null) ? ips.GetICSObject() : null;
        if (ics == null) {
            try {
				ics = Factory.newCS();
			} catch (Exception e) {
				if (LOG.isDebugEnabled()) {
					 LOG.error("ICS is not set in Publish Listener :: "+e);
				}
			}
        }
        return ics;
    }
	
	public static AssetDataManager getAssetDataManager(){
    	ICS ics = getICSInstance();
		String user = XcelProperties.getProperty(ics, "xcelerate.batchuser");
		String pass = XcelProperties.getProperty(ics, "xcelerate.batchpass");
		Session session = SessionFactory.newSession(user,pass);
		AssetDataManager mgr = (AssetDataManager) session.getManager(AssetDataManager.class.getName());
		return mgr;
	}
	
	public static String getMultiTicket() {
		LOG.info("entering getmultiticket :: ");
		String ticket = "";
    	try {
	        String casUrl = Utilities.getFileProperty("cas.url");
	        String userName = Utilities.getFileProperty("cs.username");
	        String password = Utilities.getFileProperty("cs.password");
	        LOG.info("CAS url is  :: "+casUrl+ " and username is "+userName+ " and password is "+password);
	        // Get the ticket to invoke crawler.
	        CASConfig casConfig = new CASConfig();
	        casConfig.setCasUrl(casUrl);
	        CASProvider provider = new CASProvider();
	        provider.setConfig(casConfig);
	        ticket = provider.getMultiTicket(userName, password);
	        LOG.info("multiticket value generated is :: "+ticket);
        } catch (Exception exception) {
            System.out.println("action=getCrawlerURI step=exception : " + exception);
        }
        return ticket;
    }
	
	public static void getLoginCredentials(String assetType, String assetid){
		LOG.info("entering logincredentials :: ");
		Client client = Client.create();
		String servicesUrl=getFileProperty("services.url")+assetType+"/"+assetid;
		WebResource localWebResource = client.resource(servicesUrl);
		String strMultiTicket = getMultiTicket();
		localWebResource = localWebResource.queryParam("multiticket", strMultiTicket);
		Builder localBuilder = localWebResource.header("Pragma", "auth-redirect=false");
		localBuilder.get(String.class);
		LOG.info("multiticket is generated :: "+localBuilder.get(String.class));
	}
}
