package com.wcs.firstsite.customrest.service;

import com.fatwire.rest.ServiceException;
import com.fatwire.rest.RESTResponse;
import com.wcs.firstsite.customrest.beans.AssetBean;

public interface RestResourceService {

	/**
     * Gets a static list recommendation by id.
     * @param context runtime context.
     * @param id recommendation id.
     * @return REST response.
     * @throws ServiceException if an error occurs.
     * @author Ankit
     */
	
	 RESTResponse<AssetBean> getAssetBean(String assettype, String assetid) throws ServiceException;
	 RESTResponse<String> getLoginStatus( String name,String password ) throws ServiceException;
}
