package com.wcs.firstsite.customrest.service;

import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.ws.rs.PathParam;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fatwire.assetapi.common.AssetAccessException;
import com.fatwire.assetapi.common.AssetNotExistException;
import com.fatwire.assetapi.data.AssetData;
import com.fatwire.assetapi.data.AssetDataManager;
import com.fatwire.assetapi.data.AssetId;
import com.fatwire.assetapi.data.AttributeData;
import com.fatwire.assetapi.data.BlobObject;
import com.fatwire.rest.GenericRESTResponse;
import com.fatwire.rest.RESTResponse;
import com.fatwire.rest.ServiceException;
import com.fatwire.rest.BaseResource;
import com.fatwire.util.BlobUtil;
import com.wcs.firstsite.customrest.beans.AssetBean;
import com.wcs.firstsite.customrest.beans.MediaBean;
import com.wcs.firstsite.customrest.beans.RecommendationBean;
import com.wcs.firstsite.customrest.common.Utilities;
import com.wcs.firstsite.customrest.beans.ProductBean;
import com.openmarket.xcelerate.asset.AssetIdImpl;

import java.util.ArrayList;

import com.fatwire.assetapi.query.Condition;
import com.fatwire.assetapi.query.ConditionFactory;
import com.fatwire.assetapi.query.OpTypeEnum;
import com.fatwire.assetapi.query.Query;
import com.fatwire.assetapi.query.SimpleQuery;


/**
 * Local (Content Server) implementation of the recommendation service.
 * @author Ankit
 */

public class RestResourceServiceImpl extends BaseResource implements RestResourceService
{	
		
	private static final Log LOG = LogFactory
			.getLog(RestResourceServiceImpl.class);
	 
	@Override
	public RESTResponse<AssetBean> getAssetBean(@PathParam("assettype") String assettype, @PathParam("assetid") String assetid)
			throws ServiceException {
		LOG.info("Inside RestResourceServiceImpl getAssetBean with assettype :: " +assettype+ " and assetid :: "+assetid);
		AssetBean assetBean = new AssetBean();
		AssetDataManager mgr = Utilities.getAssetDataManager();
		if (assettype != null && !assettype.equals("null")) {
			if(assettype.equalsIgnoreCase("advcols")){
				assetBean.setRecom(getRecomBean(mgr,assetid));
			}else if(assettype.equalsIgnoreCase("Product_C")){
				assetBean.setProduct(getProductBean(mgr, assetid));
			}else if(assettype.equalsIgnoreCase("Media_C")){
				assetBean.setMedia(getMediaBean(mgr, assetid));
			}
		}
		LOG.info("Inside RestResourceServiceImpl assetbean is set :: ");
		return new GenericRESTResponse<AssetBean>(assetBean);
	}
    
	public ProductBean getProductBean(AssetDataManager mgr, String assetid){
		 ProductBean productBean = new ProductBean();
		 MediaBean productMedia = new MediaBean();
		 try
	        {
			 	LOG.info("Inside RestResourceServiceImpl getProductBean with assetid :: "+assetid);
	    		AssetId productId = new AssetIdImpl("Product_C", Long.valueOf(assetid));
	    		Iterator<AssetData> it = mgr.read(Collections.singletonList(productId)).iterator();
	    		productBean.setProductId(assetid);
		        while(it.hasNext())
		        {
		        	 AssetData data = it.next();  
		        	 String name = (String)data.getAttributeData("FSIIProductName").getData();
		        	 productBean.setProductName(name);
		        	 String longDescription = (String)data.getAttributeData("FSIILongDescription").getData();
		        	 if(!longDescription.isEmpty()&& longDescription!=null){
		        		 productBean.setProductLongDescription(longDescription);
			         }
		        	 String shortDescription = (String)data.getAttributeData("FSIIProductShortDescription").getData();
		        	 if(!shortDescription.isEmpty()&& shortDescription!=null){
		        		 productBean.setProductShortDescription(shortDescription);
			         }
		        	 Double price= (Double)data.getAttributeData("FSIIPrice").getData();
		        	 productBean.setProductPrice(price);
		        	 String SKU = (String)data.getAttributeData("FSIISKU").getData();
		        	 productBean.setProductSKU(SKU);
		        	 AssetId productImage = (AssetId)data.getAttributeData("FSIIImage").getData();
		        	 productMedia = getMediaBean(mgr, String.valueOf(productImage.getId()));
		        	 productBean.setMedia(productMedia);
		        }
	         }
	        catch(AssetNotExistException assetNotExistException){
	        	LOG.error("assetNotExistException: ", assetNotExistException);
	        }
	        catch(AssetAccessException assetAccessException){
	        	LOG.error("assetAccessException: ", assetAccessException);	
	        }
	        catch(Exception E){
	        	throw E;
	        }
		LOG.info("Inside RestResourceServiceImpl productbean is set with product name :: "+productBean.getProductName());
		return productBean;
	}
	
	public RecommendationBean getRecomBean(AssetDataManager mgr, String assetid){
		RecommendationBean recomBean = new RecommendationBean();
		try{
			LOG.info("Inside RestResourceServiceImpl getRecomBean with assetid :: "+assetid);
			AssetId recId = new AssetIdImpl("AdvCols", Long.valueOf(assetid));
	        Iterator<AssetData> it = mgr.read(Collections.singletonList(recId)).iterator();
	        AssetData data = it.next();
	        String description = (String)data.getAttributeData("description").getData();
	        if(!description.isEmpty()&& description!=null){
            	recomBean.setDescription((String)description);
	        }
	        
	        @SuppressWarnings("unchecked")
			List<Map<String, AttributeData>> assets = (List<Map<String, AttributeData>>)data.getAttributeData("Manualrecs").getDataAsList();
            for (Map<String, AttributeData> asset : assets)
            {
                for (Map.Entry<String, AttributeData> entry : asset.entrySet())
                {
                    if ("assetid".equals(entry.getKey()))
                    {	
                        AssetId assetId = (AssetId)entry.getValue().getData();
                        LOG.info("Inside RestResourceServiceImpl getRecomBean inside if loop :: "+assetId.getId()+ " type :: "+assetId.getType());
                        ProductBean recAsset = new ProductBean();
                        recAsset = getProductBean(mgr, String.valueOf(assetId.getId()));
                        //recAsset.setProductId(String.valueOf(assetId.getId()));
                        recomBean.getAssets().add(recAsset);
                    }
                }
            }
		}catch(AssetNotExistException assetNotExistException){
        	LOG.error("assetNotExistException: ", assetNotExistException);
        }
        catch(AssetAccessException assetAccessException){
        	LOG.error("assetAccessException: ", assetAccessException);	
        }
        catch(Exception E){
        	throw E;
        }	
		LOG.info("Inside RestResourceServiceImpl recombean is set with value :: "+recomBean.getAssets());
        return recomBean;
	}
	 
	public MediaBean getMediaBean(AssetDataManager mgr, String assetid){
		MediaBean mediaBean = new MediaBean();
		try
        {
		 	LOG.info("Inside RestResourceServiceImpl getMediaBean with assetid :: "+assetid);
    		AssetId mediaId = new AssetIdImpl("Media_C", Long.valueOf(assetid));
    		Iterator<AssetData> it = mgr.read(Collections.singletonList(mediaId)).iterator();
	        while(it.hasNext())
	        {
	        	 AssetData data = it.next();  
	        	 Integer imageHeight = (Integer)data.getAttributeData("FSII_ImageHeight").getData();
	        	 if(imageHeight!=-1){
	        		 mediaBean.setImageHeight(imageHeight);
		         }
	        	 Integer imageWidth = (Integer)data.getAttributeData("FSII_ImageWidth").getData();
	        	 if(imageWidth!=-1){
	        		 mediaBean.setImageWidth(imageWidth);
		         }
	        	 Integer thumbHeight = (Integer)data.getAttributeData("FSII_ThumbnailHeight").getData();
	        	 if(thumbHeight!=-1){
	        		 mediaBean.setThumbHeight(thumbHeight);
		         }
	        	 Integer thumbWidth = (Integer)data.getAttributeData("FSII_ThumbnailWidth").getData();
	        	 if(thumbWidth!=-1){
	        		 mediaBean.setThumbWidth(thumbWidth);
		         }
	        	 BlobObject fileObj = (BlobObject)data.getAttributeData("FSII_ImageFile").getData();
	        	 String bloburl = BlobUtil.getBlobUrl(fileObj, mediaId);
	        	 mediaBean.setImagesrc(bloburl);
	        }
         }
        catch(AssetNotExistException assetNotExistException){
        	LOG.error("assetNotExistException: ", assetNotExistException);
        }
        catch(AssetAccessException assetAccessException){
        	LOG.error("assetAccessException: ", assetAccessException);	
        }
        catch(Exception E){
        	throw E;
        }
	LOG.info("Inside RestResourceServiceImpl mediabean is set with media src :: "+mediaBean.getImagesrc());
		return mediaBean;
	}
	
	
	@Override
	public RESTResponse<String> getLoginStatus(@PathParam("name") String name, @PathParam("password") String password)
			throws ServiceException {
		String logging="false";
		try {
			LOG.info("Inside RestResourceServiceImpl getLoginstatus with name :: " +name+ " and password :: "+password);
		AssetDataManager mgr = Utilities.getAssetDataManager();
		Condition c1 = ConditionFactory.createCondition( "FSIIUsername",OpTypeEnum.EQUALS, name );
		Condition c2 = ConditionFactory.createCondition( "FSIIPassword",OpTypeEnum.EQUALS, password);
		Condition c = c1.and( c2 ); 
		Query query = new SimpleQuery( "FSIIVisitor", "FSIIBasicVisitor", c,Arrays.asList( "name", "FSIIUsername" ) );
		query.getProperties().setIsBasicSearch( true );
		ArrayList<AssetData> list=(ArrayList<AssetData>) mgr.read(query);
		Iterator itr=list.iterator();
		while(itr.hasNext()){
			AssetData data=(AssetData)itr.next();
			if(data.getAttributeData("FSIIUsername")!=null){
				logging="true";
			}
		}
		
			} catch (AssetAccessException e) {
			// TODO Auto-generated catch block
			logging=logging+" AssetAccesException ";
			e.printStackTrace();
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			logging=logging+e.toString();
			e.printStackTrace();
		}
		
		// TODO Auto-generated method stub
		return new GenericRESTResponse<String>(logging);
	}

}
