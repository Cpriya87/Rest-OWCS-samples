package com.wcs.firstsite.customrest.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fatwire.rest.BaseResource;
import com.fatwire.rest.RESTResponse;
import com.fatwire.rest.ServiceException;
import com.wcs.firstsite.customrest.beans.AssetBean;
import com.wcs.firstsite.customrest.service.RestResourceService;

@Path(value = "/firstsite")
public class RestFirstsiteResource extends BaseResource {
	
	private static final Log LOG = LogFactory
			.getLog(RestFirstsiteResource.class);
	
	@GET
	@Path("/asset/{assettype}/{assetid}")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response getResource(@PathParam("assettype") String assettype, @PathParam("assetid") String assetid) throws ServiceException {
			LOG.info("Inside RestFirstsiteResource with assettype :: " +assettype+ " and assetid :: "+assetid);
			RestResourceService service = (RestResourceService) getBean("assetProductBeanService");
			return generateResponse(service.getAssetBean(assettype, assetid));
	}
	
	
	 @GET
	 @Path("/login/{user}/{password}")
	 @Produces({MediaType.APPLICATION_JSON})
	 public Response getLoginstatus(@PathParam ("user") String user,@PathParam ("password") String password) throws ServiceException{
	        // Obtain service (local or remote).
	    	
	    	RestResourceService service = (RestResourceService)getBean("assetProductBeanService");
	        
	        // Generate REST response.
	        return generateResponse(service.getLoginStatus(user, password));
	    }


	
}
